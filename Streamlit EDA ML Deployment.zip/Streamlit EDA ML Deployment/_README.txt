1. Create app.py file in folder
2. Write your Python / Streamlit codes
3. Execute streamlit app.py
4. Visit localhost url generated in Command Prompt
5. Upload final repo to GitHub
5. Go to https://share.streamlit.io to deploy app via GitHub